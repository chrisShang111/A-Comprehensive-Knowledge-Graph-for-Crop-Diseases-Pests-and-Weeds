# Chinese Plant Protection Knowledge Graph (CPKG) Dataset

Official release of the **Chinese Plant Protection Knowledge Graph (CPKG)** dataset.
This package contains the raw standardized source literature corpus and all extracted semantic triples partitioned across the 14 canonical ontology relations.

---

## 1. Directory Structure

```text
CPKG-Dataset/
├── README.md                      # Dataset specifications and usage guide
├── triples.csv                    # Master knowledge graph triples (73,310 facts)
├── corpus/                        # Raw literature corpus
│   ├── README.md                  # Corpus provenance and schema description
│   └── corpus.jsonl               # 3,999 standardized source monographs
└── relations/                     # Extracted triples partitioned by relation (14 tables, sum = 73,310)
    ├── affects_plant_part.csv     # 9,228 facts  (Affected plant parts & organs)
    ├── damages_crop.csv           # 6,400 facts  (Damaged host agricultural crops)
    ├── favored_by_condition.csv   # 8,677 facts  (Favorable environmental conditions)
    ├── has_chemical_control_plan.csv # 15,487 facts (Chemical control formulations & prescriptions)
    ├── has_habit.csv              # 3,506 facts  (Biological & ecological habits)
    ├── has_morphological_feature.csv # 5,431 facts (Diagnostic morphological characteristics)
    ├── has_pathogen.csv           #   646 facts  (Associated biological pathogens)
    ├── has_scientific_name.csv    #   352 facts  (Source-reported scientific names)
    ├── has_symptom.csv            # 10,652 facts (Organ-specific disease & pest symptoms)
    ├── managed_by.csv             # 10,131 facts (Agronomic & physical management practices)
    ├── occurs_in_region.csv       # 1,529 facts  (Geographic occurrence regions)
    ├── overwinters_as.csv         #   184 facts  (Overwintering developmental stages)
    ├── overwinters_in.csv         # 1,061 facts  (Overwintering micro-habitats & sites)
    └── transmits_disease.csv      #    26 facts  (Vector-transmitted secondary diseases)
```

---

## 2. Relational Summary (73,310 Total Facts)

| Relation Table | Facts | Head Entity Type | Tail Entity Type | Description |
| :--- | :---: | :--- | :--- | :--- |
| `affects_plant_part.csv` | 9,228 | Disease, Pest | PlantPart | Feeding / infection organ or tissue |
| `damages_crop.csv` | 6,400 | Disease, Pest, Weed | Crop | Host agricultural crop damaged |
| `favored_by_condition.csv` | 8,677 | Disease, Pest, Weed | EnvironmentalCondition | Temperature, humidity, soil, weather triggers |
| `has_chemical_control_plan.csv` | 15,487 | Disease, Pest, Weed | ChemicalControlPlan | Chemical pesticide formulation and dosage |
| `has_habit.csv` | 3,506 | Pest | BiologicalHabit | Feeding, flight, phototaxis, reproduction habits |
| `has_morphological_feature.csv` | 5,431 | Weed | MorphologicalFeature | Anatomical and diagnostic characteristics |
| `has_pathogen.csv` | 646 | Disease | Pathogen | Fungi, bacteria, viruses, phytoplasmas |
| `has_scientific_name.csv` | 352 | Pest, Weed | ScientificName | Latin binomial / superfamily names in source |
| `has_symptom.csv` | 10,652 | Disease, Pest | Symptom | Macro- and micro-symptoms on plant organs |
| `managed_by.csv` | 10,131 | Disease, Pest, Weed | NonChemicalControlPlan | Agronomic, biological, physical cultural controls |
| `occurs_in_region.csv` | 1,529 | Disease, Pest, Weed | GeographicRegion | Provincial and regional distribution in China |
| `overwinters_as.csv` | 184 | Disease, Pest | OverwinteringForm | Overwintering developmental stage or form |
| `overwinters_in.csv` | 1,061 | Disease, Pest | OverwinteringSite | Overwintering shelter, soil, bark, or host debris |
| `transmits_disease.csv` | 26 | Pest | Disease | Viral or bacterial diseases vectored by pests |
| **Total Triples** | **73,310** | - | - | **Sum of all 14 relation tables** |

---

## 3. Data Format & Field Specifications

All CSV files are encoded in UTF-8. The master table `triples.csv` and the 14 relation tables share a standardized columnar schema:
- `triple_id`: Unique identifier for the semantic fact (e.g. `T000001` to `T073310`).
- `head_name`: Name of the source agricultural threat (e.g. `黄瓜白粉病`, `玉米螟`).
- `head_type`: Ontological class of the head (`Disease`, `Pest`, or `Weed`).
- `relation`: Canonical camelCase relation identifier (e.g. `hasSymptom`, `damagesCrop`).
- `tail_name`: Atomic, canonical target entity or descriptive proposition.
- `tail_type`: Ontological class of the tail entity.
- `affected_crop`: Primary host crop associated with the occurrence record.
