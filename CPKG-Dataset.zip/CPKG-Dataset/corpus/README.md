# CPKG Raw Monograph Corpus (corpus.jsonl)

This directory contains the raw standardized Chinese crop protection literature corpus.

## Specifications
- **Format**: JSON Lines (`corpus.jsonl`)
- **Total Records**: 3,999 documents
- **Host Crop Coverage**: 112 agricultural crops
- **Target Threat Coverage**: Plant diseases, insect pests, and agricultural weeds
- **Fields per Record**:
  - `id`: Unique source document identifier (e.g., `doc_5efde102dfe1`)
  - `name`: Chinese name of the target disease, pest, or weed (e.g., `山楂叶斑病`, `东方盔蚧`, `小画眉草`)
  - `type`: Categorical classification (`Disease`, `Pest`, or `Weed`)
  - `crop`: Primary host agricultural crop (e.g., `山楂`, `水稻`)
  - `category`: Broad agronomic or botanical category (32 categories, e.g., `仁果类`, `单子叶种子植物杂草`)
  - `latin_name`: Latin binomial or scientific taxon name reported in source literature
  - `source_path`: Hierarchical archival path in source repository (e.g., `仁果类/山楂/病害/山楂叶斑病/info.json`)
  - `text`: Verbatim narrative description covering symptoms, morphology, etiology, overwintering, habits, and integrated control measures
  - `family`: Botanical family taxonomy (present for weed records)
