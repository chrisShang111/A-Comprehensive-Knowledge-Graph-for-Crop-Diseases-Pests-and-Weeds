# CPKG Knowledge Extraction & Benchmark Suite

Official code and prompt repository for the **Chinese Plant Protection Knowledge Graph (CPKG)**, structured for academic transparency and reproducibility in *Nature Scientific Data* (2025).

---

## 1. Directory Structure

```text
CPKG-Code/
├── README.md                      # Code usage & benchmark reproduction guide
├── requirements.txt               # Dependencies (requests, tabulate)
├── .env.example                   # API configuration template
│
├── prompts/                       # Prompt Engineering & Ontology Constraints
│   ├── extraction_prompt.md       # Primary extraction prompt template
│   ├── validation_prompt.md       # Validation & repair prompt template
│   └── schema.json                # Canonical 14-relation ontology schema
│
├── service/                       # Knowledge Extraction Agent & Service
│   ├── __init__.py
│   ├── extraction_agent.py        # Schema-constrained LLM extraction agent
│   ├── llm_client.py              # Resilient LLM API client (retries, backoff)
│   ├── schema.py                  # 14 canonical relation constraint validator
│   └── config.py                  # Service configuration loader
│
└── evaluation/                    # Table 3 Benchmark Evaluation Suite
    ├── evaluate_benchmark.py      # Standalone reproduction script for Table 3
    ├── audit_precision_ledger_220.csv  # 5,958 audited precision propositions
    ├── audit_omission_ledger_220.csv   # 1,435 candidate omission propositions
    └── manifest_220_complete_distinct.csv # 220 sampled monograph registry
```

---

## 2. Quick Start

### Step 1: Environment Setup
```bash
python -m venv venv
# On Windows:
venv\Scripts\activate
# On Linux/macOS:
source venv/bin/activate

pip install -r requirements.txt
```

### Step 2: Reproduce Official Benchmark Metrics (Table 3)
To reproduce the official evaluation metrics across all 14 canonical ontology relations:
```bash
python evaluation/evaluate_benchmark.py
```

Expected output:
- **Precision**: **97.83%** (5,829 / 5,958)
- **Recall**: **86.99%** (5,829 / 6,701)
- **F1-Score**: **92.09%** (TP=5,829, FP=129, FN=872)

### Step 3: Run Extraction Agent with Custom API
Configure your OpenAI-compatible API key in `.env`:
```ini
OPENAI_API_KEY=sk-your-key-here
OPENAI_BASE_URL=https://api.openai.com/v1
PRIMARY_MODEL=gpt-4o
```

Then invoke the extraction agent in Python:
```python
from service.config import Config
from service.llm_client import LLMClient
from service.extraction_agent import ExtractionAgent

cfg = Config()
client = LLMClient(api_key=cfg.openai_api_key, base_url=cfg.openai_base_url, primary_model=cfg.primary_model)
agent = ExtractionAgent(client)

triples = agent.extract_triples(
    text="山楂黑星病主要为害叶片、果实及花蕾。发病初期叶背出现淡黄褐色斑点...",
    target_name="山楂黑星病",
    target_type="Disease",
    crop_name="山楂"
)
for t in triples:
    print(t)
```
