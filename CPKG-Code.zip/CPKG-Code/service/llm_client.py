#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Lightweight universal OpenAI-compatible LLM client.

Supports standard OpenAI-compatible LLM API endpoints and services.
"""
from __future__ import annotations

import json
import time
import urllib.request
import urllib.error
from typing import Any, Dict, List, Optional

try:
    import requests
except ImportError:
    requests = None

try:
    from .config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL, REQUEST_TIMEOUT, MAX_RETRIES
except ImportError:
    try:
        from config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL, REQUEST_TIMEOUT, MAX_RETRIES
    except ImportError:
        from agent.config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL, REQUEST_TIMEOUT, MAX_RETRIES


class LLMClient:
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: Optional[str] = None,
        timeout: int = REQUEST_TIMEOUT,
    ):
        self.api_key = api_key if api_key is not None else LLM_API_KEY
        self.base_url = (base_url or LLM_BASE_URL).rstrip("/")
        self.model = model or LLM_MODEL
        self.timeout = timeout
        self.endpoint = f"{self.base_url}/chat/completions"

    def is_configured(self) -> bool:
        return bool(self.api_key and self.base_url and self.model)

    def chat_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.0,
        max_tokens: int = 4096,
        json_mode: bool = False,
    ) -> str:
        """Call chat completion API with retry support."""
        if not self.is_configured():
            missing = []
            if not self.api_key: missing.append("OPENAI_API_KEY")
            if not self.base_url: missing.append("OPENAI_BASE_URL")
            if not self.model: missing.append("PRIMARY_MODEL (or OPENAI_MODEL)")
            raise ValueError(
                f"LLM API is not fully configured. Missing: {', '.join(missing)}. "
                "Please configure these environment variables before running LLM operations."
            )

        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        last_error = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                if requests is not None:
                    resp = requests.post(
                        self.endpoint,
                        headers=headers,
                        json=payload,
                        timeout=self.timeout,
                    )
                    resp.raise_for_status()
                    data = resp.json()
                else:
                    req = urllib.request.Request(
                        self.endpoint,
                        data=json.dumps(payload).encode("utf-8"),
                        headers=headers,
                    )
                    with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                        data = json.loads(resp.read().decode("utf-8"))

                choices = data.get("choices", [])
                if not choices:
                    raise ValueError(f"Empty choices in LLM response: {data}")

                msg = choices[0].get("message", {})
                content = msg.get("content") or msg.get("reasoning_content") or ""
                return content.strip()

            except Exception as e:
                last_error = e
                time.sleep(attempt * 1.5)

        raise RuntimeError(f"LLM request failed after {MAX_RETRIES} attempts: {last_error}")
