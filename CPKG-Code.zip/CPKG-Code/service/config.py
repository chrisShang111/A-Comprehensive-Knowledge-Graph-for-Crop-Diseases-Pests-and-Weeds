#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CPKG Agent Configuration Module."""
import os
from pathlib import Path

AGENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = AGENT_DIR.parent
DATA_DIR = PROJECT_ROOT / "data"
CORPUS_DIR = PROJECT_ROOT / "corpus"
PROMPTS_DIR = PROJECT_ROOT / "prompts"

# Load .env file if present
_env_file = PROJECT_ROOT / ".env"
if _env_file.exists():
    with open(_env_file, "r", encoding="utf-8") as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _v = _line.split("=", 1)
                os.environ.setdefault(_k.strip(), _v.strip())

LLM_API_KEY = os.getenv("OPENAI_API_KEY") or os.getenv("LLM_API_KEY") or ""
LLM_BASE_URL = (os.getenv("OPENAI_BASE_URL") or os.getenv("LLM_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
LLM_MODEL = os.getenv("PRIMARY_MODEL") or os.getenv("OPENAI_MODEL") or os.getenv("LLM_MODEL") or "gpt-4o"
BACKUP_MODEL = os.getenv("BACKUP_MODEL") or "gpt-4o-mini"
REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "60"))
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))


class Config:
    """Config container for CPKG agent and pipeline services."""

    def __init__(self):
        self.openai_api_key = LLM_API_KEY
        self.openai_base_url = LLM_BASE_URL
        self.primary_model = LLM_MODEL
        self.backup_model = BACKUP_MODEL
        self.request_timeout = REQUEST_TIMEOUT
        self.max_retries = MAX_RETRIES

