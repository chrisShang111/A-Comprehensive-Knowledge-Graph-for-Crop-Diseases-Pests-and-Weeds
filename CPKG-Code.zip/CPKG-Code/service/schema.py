#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CPKG Canonical Ontology Schema and Validation Rules.

Defines the 14 canonical relation types, allowed head/tail entity types,
tail length constraints, and signature validation functions.
"""
from __future__ import annotations

from typing import Dict, FrozenSet, Tuple

# 14 Canonical Relations in CPKG
ALLOWED_RELATIONS: Tuple[str, ...] = (
    "affectsPlantPart",
    "damagesCrop",
    "favoredByCondition",
    "hasChemicalControlPlan",
    "hasHabit",
    "hasMorphologicalFeature",
    "hasPathogen",
    "hasScientificName",
    "hasSymptom",
    "managedBy",
    "occursInRegion",
    "overwintersAs",
    "overwintersIn",
    "transmitsDisease",
)

# Standard Tail Types for each relation
TAIL_TYPE: Dict[str, str] = {
    "affectsPlantPart": "PlantPart",
    "damagesCrop": "Crop",
    "favoredByCondition": "Condition",
    "hasChemicalControlPlan": "ChemicalControlPlan",
    "hasHabit": "Habit",
    "hasMorphologicalFeature": "MorphologicalFeature",
    "hasPathogen": "Pathogen",
    "hasScientificName": "ScientificName",
    "hasSymptom": "Symptom",
    "managedBy": "ControlMeasure",
    "occursInRegion": "Region",
    "overwintersAs": "OverwinteringStage",
    "overwintersIn": "OverwinteringSite",
    "transmitsDisease": "Disease",
}

# Maximum character lengths for tail entities
MAX_TAIL_LEN: Dict[str, int] = {
    "affectsPlantPart": 30,
    "damagesCrop": 30,
    "favoredByCondition": 45,
    "hasChemicalControlPlan": 160,
    "hasHabit": 60,
    "hasMorphologicalFeature": 45,
    "hasPathogen": 90,
    "hasScientificName": 90,
    "hasSymptom": 45,
    "managedBy": 60,
    "occursInRegion": 30,
    "overwintersAs": 30,
    "overwintersIn": 40,
    "transmitsDisease": 45,
}

# Permitted Head Types for each relation
HEAD_TYPES: Dict[str, FrozenSet[str]] = {
    "affectsPlantPart": frozenset({"Disease", "Pest"}),
    "damagesCrop": frozenset({"Disease", "Pest", "Weed"}),
    "favoredByCondition": frozenset({"Disease", "Pest", "Weed"}),
    "hasChemicalControlPlan": frozenset({"Disease", "Pest", "Weed"}),
    "hasHabit": frozenset({"Disease", "Pest", "Weed"}),
    "hasMorphologicalFeature": frozenset({"Weed"}),
    "hasPathogen": frozenset({"Disease"}),
    # The released ontology retains scientific names for both pests and weeds.
    # Disease Latin names belong in hasPathogen and are never attached directly
    # through hasScientificName.
    "hasScientificName": frozenset({"Pest", "Weed"}),
    "hasSymptom": frozenset({"Disease", "Pest", "Weed"}),
    "managedBy": frozenset({"Disease", "Pest", "Weed"}),
    "occursInRegion": frozenset({"Disease", "Pest", "Weed"}),
    "overwintersAs": frozenset({"Disease", "Pest", "Weed"}),
    "overwintersIn": frozenset({"Disease", "Pest", "Weed"}),
    "transmitsDisease": frozenset({"Pest"}),
}

# Relations that can be extracted from free text
FREE_TEXT_EXTRACTABLE_RELATIONS: Tuple[str, ...] = tuple(
    r for r in ALLOWED_RELATIONS if r != "belongsToFamily"
)

TAIL_TYPE_ALIASES = {
    ("overwintersAs", "LifeStage"): "OverwinteringStage",
    ("overwintersAs", "PathogenForm"): "OverwinteringStage",
}


def canonical_tail_type(relation: str, tail_type: str = "") -> str:
    """Return the canonical released tail type for a relation."""
    relation = str(relation or "").strip()
    tail_type = str(tail_type or "").strip()
    if (relation, tail_type) in TAIL_TYPE_ALIASES:
        return TAIL_TYPE_ALIASES[(relation, tail_type)]
    return TAIL_TYPE.get(relation, tail_type)


def validate_relation_signature(head_type: str, relation: str, tail_type: str) -> Tuple[bool, str]:
    """Validate head_type -> relation -> tail_type signature."""
    head_type = str(head_type or "").strip()
    relation = str(relation or "").strip()
    tail_type = canonical_tail_type(relation, tail_type)
    if relation not in ALLOWED_RELATIONS:
        return False, f"Relation '{relation}' not in canonical schema"
    if head_type not in HEAD_TYPES[relation]:
        return False, f"Head type '{head_type}' not allowed for relation '{relation}'"
    if tail_type != TAIL_TYPE[relation]:
        return False, f"Tail type '{tail_type}' does not match expected '{TAIL_TYPE[relation]}'"
    return True, ""


def prompt_schema_lines() -> str:
    """Format schema definition matrix for LLM prompt injection."""
    lines = []
    for relation in ALLOWED_RELATIONS:
        heads = "/".join(sorted(HEAD_TYPES[relation]))
        lines.append(f"- {relation}: {heads} -> {TAIL_TYPE[relation]} (max len {MAX_TAIL_LEN[relation]})")
    return "\n".join(lines)
