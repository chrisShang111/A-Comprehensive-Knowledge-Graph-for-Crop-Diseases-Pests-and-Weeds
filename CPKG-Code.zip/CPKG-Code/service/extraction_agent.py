#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CPKG Multi-relation Knowledge Extraction Agent.

Coordinates LLM prompt construction, candidate triple generation,
schema constraint enforcement, and fallback parsing.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    from .schema import ALLOWED_RELATIONS, HEAD_TYPES, TAIL_TYPE, MAX_TAIL_LEN, validate_relation_signature
    from .llm_client import LLMClient
except ImportError:
    try:
        from schema import ALLOWED_RELATIONS, HEAD_TYPES, TAIL_TYPE, MAX_TAIL_LEN, validate_relation_signature
        from llm_client import LLMClient
    except ImportError:
        from agent.schema import ALLOWED_RELATIONS, HEAD_TYPES, TAIL_TYPE, MAX_TAIL_LEN, validate_relation_signature
        from agent.llm_client import LLMClient


EXTRACTION_SYSTEM_PROMPT = """你是一个严谨的农业知识图谱信息抽取专家。
请根据提供的农作物病虫草害原文，抽取精准的知识图谱三元组。

抽取规则：
1. 只能抽取文本中有明确依据的事实，严禁幻觉和主观推测。
2. 关系仅限于以下预定义的 14 种关系：
   - affectsPlantPart (危害部位, PlantPart, 如 叶片、果实、茎秆)
   - damagesCrop (为害作物, Crop, 如 苹果、黄瓜、水稻)
   - favoredByCondition (发病条件, Condition, 如 高温高湿、密植郁闭)
   - hasChemicalControlPlan (化学防治, ChemicalControlPlan, 如 50%多菌灵可湿性粉剂1000倍液)
   - hasHabit (生活习性, Habit, 如 趋光性、成虫昼伏夜出)
   - hasMorphologicalFeature (形态特征, MorphologicalFeature, 如 根状茎粗短、叶披针形)
   - hasPathogen (病原物, Pathogen, 如 苹果白粉菌)
   - hasScientificName (学名/拉丁名, ScientificName)
   - hasSymptom (危害症状, Symptom, 如 叶片变黄、水渍状病斑)
   - managedBy (综合农业/物理/生物防治, ControlMeasure, 如 清除病残体、轮作、诱虫灯)
   - occursInRegion (分布区域, Region, 如 华北、长江流域)
   - overwintersAs (越冬形态, OverwinteringStage, 如 蛹、菌丝体、卵)
   - overwintersIn (越冬场所, OverwinteringSite, 如 土壤中、病残体、树皮裂缝)
   - transmitsDisease (传播病害, Disease)
   - belongsToFamily (植物科属, PlantFamily)

3. 【各模块语义完整性前置保障硬红线】：
   - 抽取必须以自足完整的陈述事实命题为前提，严禁粗暴截断原文条件与核心修饰语；
   - hasChemicalControlPlan 必须保留完整的制剂名称、浓度、剂型与稀释倍数（如“50%多菌灵可湿性粉剂1000倍液”），严禁截断为孤立药物名称；
   - hasSymptom 必须包含受害部位与具体病变形态（如“叶片表面水渍状褐色角斑”），严禁抽取“暗褐色”、“严重”等无主裸形容词，亦严禁抽取“枝干”、“叶片”等无异常病征的裸器官；
   - managedBy 必须保留完整具体的可执行农事措施与操作细节，严禁抽象为空洞词汇；
   - 严禁否定范围截断：凡出现“除[X]外遍布全国”、“除[X]未见发生”，[X]属于排除项，严禁抽取为 occursInRegion；凡出现“食尽[A]仅残留[B]”，[B]属于免受害残余部位，严禁抽取 affectsPlantPart -> [B]。

请以严格的 JSON 格式输出，格式如下：
{
  "triples": [
    {
      "head_name": "实体名",
      "head_type": "Disease/Pest/Weed",
      "relation": "关系名",
      "tail_name": "尾实体名",
      "tail_type": "尾实体类型"
    }
  ]
}
"""


class ExtractionAgent:
    def __init__(self, llm_client: Optional[LLMClient] = None):
        self.client = llm_client or LLMClient()

    def extract_from_document(
        self,
        text: str,
        target_name: str,
        target_type: str,
        crop: str = "",
    ) -> List[Dict[str, Any]]:
        """Extract validated triples from a single document text."""
        if not text or not text.strip():
            return []

        # Fail closed on technical failures. Never convert an API/JSON failure into
        # apparently valid source-grounded triples through keyword heuristics.
        if not self.client.is_configured():
            raise RuntimeError("LLM is not configured; extraction cannot safely fall back to keyword guesses")
        prompt_path = Path(__file__).resolve().parent.parent / "prompts" / "extraction_prompt.md"
        if not prompt_path.is_file():
            raise FileNotFoundError(f"Production extraction prompt missing: {prompt_path}")
        production_prompt = prompt_path.read_text(encoding="utf-8-sig")
        if len(text) > 40000:
            raise ValueError("Source text exceeds the supported single-call size. Segment by source proposition with evidence-preserving chunking, not truncation.")
        user_prompt = f"""【目标实体】
名称：{target_name}
类型：{target_type}
相关作物：{crop}

【原始文本】
{text}

请抽取以上实体的知识三元组，以 JSON 输出。"""

        messages = [
            {"role": "system", "content": production_prompt},
            {"role": "user", "content": user_prompt},
        ]

        response = self.client.chat_completion(messages, temperature=0.0, json_mode=True)
        triples = self._parse_json_triples(response, target_name, target_type, crop)

        # Enforce canonical schema and deduplication
        valid_triples = []
        seen_keys = set()
        for t in triples:
            head = t["head_name"]
            htype = t["head_type"]
            rel = t["relation"]
            tail = t["tail_name"]
            ttype = t["tail_type"]
            affected = t.get("affected_crop") or crop

            # Validate signature
            ok, reason = validate_relation_signature(htype, rel, ttype)
            if not ok:
                continue

            # Do not silently chop off important doses, temperatures or qualifiers.
            max_len = MAX_TAIL_LEN.get(rel, 100)
            if len(tail) > max_len:
                raise ValueError(f"Relation {rel} tail exceeds {max_len} chars and requires review: {tail!r}")
            context = t.get("relation_context") or {}
            if not isinstance(context, dict):
                raise ValueError("relation_context must be a JSON object")
            evidence = t.get("evidence", "")
            if not evidence or evidence not in text:
                raise ValueError(f"Evidence must be verbatim in the source for {rel}: {tail!r}")
            key = (head, htype, rel, tail, affected, json.dumps(context, ensure_ascii=False, sort_keys=True))
            if key in seen_keys:
                continue
            seen_keys.add(key)

            triple_id = "triple_" + hashlib.md5(f"{head}_{rel}_{tail}_{affected}".encode("utf-8")).hexdigest()[:16]
            valid_triples.append({
                "triple_id": triple_id,
                "head_name": head,
                "head_type": htype,
                "relation": rel,
                "tail_name": tail,
                "tail_type": ttype,
                "affected_crop": affected,
                "relation_context": context,
                "evidence": evidence,
            })

        return valid_triples

    def _parse_json_triples(
        self,
        raw_output: str,
        target_name: str,
        target_type: str,
        crop: str,
    ) -> List[Dict[str, Any]]:
        """Parse LLM JSON response into candidate list."""
        text = raw_output.strip()
        text = re.sub(r"^```(?:json)?", "", text).strip()
        text = re.sub(r"```$", "", text).strip()

        try:
            data = json.loads(text)
        except Exception:
            m = re.search(r"\{.*\}", text, re.DOTALL)
            if m:
                try:
                    data = json.loads(m.group(0))
                except Exception as exc:
                    raise ValueError("Invalid LLM JSON output") from exc
            else:
                raise ValueError("Invalid LLM JSON output")

        if isinstance(data, list):
            raw_list = data
        elif isinstance(data, dict):
            raw_list = data.get("items", data.get("triples", []))
        else:
            raise ValueError("LLM must return a JSON object or list")
        if not isinstance(raw_list, list):
            raise ValueError("LLM items/triples must be a list")

        results = []
        for item in raw_list:
            if not isinstance(item, dict):
                continue
            head = str(item.get("head_name") or target_name).strip()
            htype = str(item.get("head_type") or target_type).strip()
            if head != target_name or htype != target_type:
                raise ValueError("Output head/type does not match the current source record")
            rel = (item.get("relation") or "").strip()
            tail = (item.get("tail_name") or item.get("tail") or "").strip()
            ttype = (item.get("tail_type") or TAIL_TYPE.get(rel, "")).strip()

            if head and rel and tail:
                results.append({
                    "head_name": head,
                    "head_type": htype,
                    "relation": rel,
                    "tail_name": tail,
                    "tail_type": ttype,
                    "affected_crop": crop,
                    "relation_context": item.get("relation_context") or {},
                    "evidence": str(item.get("evidence") or "").strip(),
                })
        return results

    def _heuristic_extraction(
        self,
        text: str,
        target_name: str,
        target_type: str,
        crop: str,
    ) -> List[Dict[str, Any]]:
        """Fast heuristic fallback extraction based on domain keywords and section titles."""
        triples = []
        if crop and crop != "全作物/杂草":
            triples.append({
                "head_name": target_name,
                "head_type": target_type,
                "relation": "damagesCrop",
                "tail_name": crop,
                "tail_type": "Crop",
                "affected_crop": crop,
            })

        # Plant Parts
        parts = ["叶片", "果实", "茎秆", "根部", "花蕾", "穗部", "枝条", "新梢", "幼芽", "块茎"]
        for p in parts:
            if p in text:
                triples.append({
                    "head_name": target_name,
                    "head_type": target_type,
                    "relation": "affectsPlantPart",
                    "tail_name": p,
                    "tail_type": "PlantPart",
                    "affected_crop": crop,
                })

        return triples
