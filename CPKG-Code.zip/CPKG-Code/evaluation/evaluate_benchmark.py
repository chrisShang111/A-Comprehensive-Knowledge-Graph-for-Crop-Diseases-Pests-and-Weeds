import os, sys, csv
from collections import defaultdict

sys.stdout.reconfigure(encoding='utf-8')

EVAL_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(EVAL_DIR)
PREC_CSV = os.path.join(EVAL_DIR, 'audit_precision_ledger_220.csv')
OMIS_CSV = os.path.join(EVAL_DIR, 'audit_omission_ledger_220.csv')
MANIFEST_CSV = os.path.join(EVAL_DIR, 'manifest_220_complete_distinct.csv')
OUTPUT_MATRIX_CSV = os.path.join(EVAL_DIR, 'final_14_relation_evaluation_matrix.csv')
OUTPUT_STRATA_CSV = os.path.join(EVAL_DIR, 'final_strata_evaluation_matrix.csv')

GROUP_A_RELATIONS = {
    "damagesCrop": "危害作物",
    "affectsPlantPart": "危害植物组织器官部位",
    "hasSymptom": "病症病状表现",
    "hasMorphologicalFeature": "植株形态重要器官解剖结构（杂草）",
    "hasPathogen": "病原微生物",
    "hasScientificName": "双名法拉丁学名"
}

GROUP_B_RELATIONS = {
    "favoredByCondition": "发生/诱发气象条件（温湿度、雨量）",
    "hasChemicalControlPlan": "化学防治药剂配方（有效成分、剂型、浓度/用量）",
    "managedBy": "农业综合防治措施（非化学药剂的管理措施）",
    "overwintersAs": "越冬越夏形态",
    "overwintersIn": "越冬越夏场所",
    "hasHabit": "生活习性（趋性、行为方式）",
    "occursInRegion": "分布省份/地域",
    "transmitsDisease": "传播病害介体"
}

ORDERED_RELS = [
    "damagesCrop", "affectsPlantPart", "hasSymptom", "hasMorphologicalFeature",
    "hasPathogen", "hasScientificName", "favoredByCondition", "hasChemicalControlPlan",
    "managedBy", "overwintersAs", "overwintersIn", "hasHabit", "occursInRegion", "transmitsDisease"
]

def run_evaluation(include_incompatible=False, eval_mode='pipeline_raw'):
    """
    eval_mode options:
      - 'pipeline_raw': Pre-cleaning pipeline extraction evaluation (verdict column, 5,967 facts).
      - 'graph_adjudicated': Post-cleaning released graph evaluation with T003086 adjudicated as TP (5,958 resident facts).
      - 'graph_raw_conservative': Post-cleaning released graph evaluation retaining raw pre-cleaning verdict for T003086 (5,958 resident facts).
      - 'unconstrained_baseline': Reference baseline with all 1,435 raw candidate proposals.
    """
    doc_to_strat = {}
    if os.path.exists(MANIFEST_CSV):
        with open(MANIFEST_CSV, "r", encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                st = r.get("stratum") or r.get("target_type") or r.get("type", "Pest")
                doc_to_strat[r["doc_id"]] = st

    # 1. Precision ledger
    rel_prec = defaultdict(lambda: {'tp': 0, 'fp': 0, 'purged_fp': 0})
    strata_prec = defaultdict(lambda: {'tp': 0, 'fp': 0, 'docs': set()})
    with open(PREC_CSV, "r", encoding="utf-8-sig") as f:
        prec_rows = list(csv.DictReader(f))
        for r in prec_rows:
            rel = r["relation"]
            doc = r.get("doc_id", "")
            in_graph = (r.get("in_released_graph", "YES") == "YES")
            strat = doc_to_strat.get(doc, "Pest")

            if eval_mode == 'pipeline_raw' or eval_mode == 'unconstrained_baseline':
                v = r["verdict"]
                if v == "TP":
                    rel_prec[rel]['tp'] += 1
                    strata_prec[strat]['tp'] += 1
                elif v == "FP":
                    rel_prec[rel]['fp'] += 1
                    strata_prec[strat]['fp'] += 1
            elif eval_mode == 'graph_adjudicated':
                if not in_graph:
                    rel_prec[rel]['purged_fp'] += 1
                    continue
                v = r.get("post_curation_verdict") or r["verdict"]
                if v == "TP":
                    rel_prec[rel]['tp'] += 1
                    strata_prec[strat]['tp'] += 1
                elif v == "FP":
                    rel_prec[rel]['fp'] += 1
                    strata_prec[strat]['fp'] += 1
            elif eval_mode == 'graph_raw_conservative':
                if not in_graph:
                    rel_prec[rel]['purged_fp'] += 1
                    continue
                v = r["verdict"]  # keep raw FP for T003086
                if v == "TP":
                    rel_prec[rel]['tp'] += 1
                    strata_prec[strat]['tp'] += 1
                elif v == "FP":
                    rel_prec[rel]['fp'] += 1
                    strata_prec[strat]['fp'] += 1

            strata_prec[strat]['docs'].add(doc)

    # 2. Omission ledger
    rel_omis = defaultdict(lambda: {'raw_fn': 0, 'kg_covered': 0, 'genuine_fn': 0, 'incompatible': 0})
    strata_omis = defaultdict(lambda: {'raw_fn': 0, 'kg_covered': 0, 'genuine_fn': 0, 'incompatible': 0})
    with open(OMIS_CSV, "r", encoding="utf-8-sig") as f:
        omis_rows = list(csv.DictReader(f))
        for r in omis_rows:
            rel = r["relation"]
            doc = r.get("doc_id", "")
            strat = r.get("stratum") or doc_to_strat.get(doc, "Pest")
            is_compliant = r.get("is_schema_compliant", "YES") == "YES"
            status = r.get("kg_status", "")
            cov = (status == "KG_ALREADY_CAPTURED")

            if not is_compliant and not include_incompatible:
                rel_omis[rel]['incompatible'] += 1
                strata_omis[strat]['incompatible'] += 1
                continue

            rel_omis[rel]['raw_fn'] += 1
            strata_omis[strat]['raw_fn'] += 1
            if cov:
                rel_omis[rel]['kg_covered'] += 1
                strata_omis[strat]['kg_covered'] += 1
            else:
                rel_omis[rel]['genuine_fn'] += 1
                strata_omis[strat]['genuine_fn'] += 1

    return prec_rows, omis_rows, rel_prec, strata_prec, rel_omis, strata_omis

def print_evaluation_report(mode_name, prec_rows, omis_rows, rel_prec, strata_prec, rel_omis, strata_omis, export_csv=False):
    tot_tp = sum(v['tp'] for v in rel_prec.values())
    tot_fp = sum(v['fp'] for v in rel_prec.values())
    tot_pred = tot_tp + tot_fp
    tot_raw_fn = sum(v['raw_fn'] for v in rel_omis.values())
    tot_kg_cov = sum(v['kg_covered'] for v in rel_omis.values())
    tot_gen_fn = sum(v['genuine_fn'] for v in rel_omis.values())
    tot_incompat = sum(v['incompatible'] for v in rel_omis.values())

    overall_prec = tot_tp / max(1, tot_pred) * 100
    overall_doc_r = tot_tp / max(1, tot_tp + tot_raw_fn) * 100
    overall_doc_f1 = 2 * overall_prec * overall_doc_r / max(1e-6, overall_prec + overall_doc_r)
    overall_kg_r = tot_tp / max(1, tot_tp + tot_gen_fn) * 100
    overall_kg_f1 = 2 * overall_prec * overall_kg_r / max(1e-6, overall_prec + overall_kg_r)

    print("=" * 105)
    print(f"EVALUATION RESULTS: {mode_name}")
    print("=" * 105)
    if tot_incompat > 0:
        print(f"Schema Adjudication: Excluded {tot_incompat} out-of-scope proposals (108 Disease hasHabit, 11 Weed hasHabit, 8 Pest hasMorphologicalFeature)")
    print(f"Precision (TP / [TP + FP])           : {overall_prec:.2f}% ({tot_tp:,} / {tot_pred:,})")
    print(f"Document-Level Recall (TP / [TP+Raw]): {overall_doc_r:.2f}% ({tot_tp:,} / {tot_tp + tot_raw_fn:,}) | Doc-F1: {overall_doc_f1:.2f}%")
    print(f"KG-Adjusted Recall (TP / [TP+GenFN]) : {overall_kg_r:.2f}% ({tot_tp:,} / {tot_tp + tot_gen_fn:,}) | KG-F1 : {overall_kg_f1:.2f}%")
    print("-" * 105)

    print("\n" + "=" * 105)
    print("RELATION-LEVEL BENCHMARK EVALUATION METRICS (14 ONTOLOGY RELATIONS)")
    print("=" * 105)
    print(f"{'Relation':<25s} | {'TP':>5s} | {'FP':>4s} | {'Prec(%)':>7s} | {'RawFN':>5s} | {'CovFN':>5s} | {'GenFN':>5s} | {'KG-Rec(%)':>9s} | {'KG-F1(%)':>8s}")
    print("-" * 105)

    matrix_rows = []
    for rel in ORDERED_RELS:
        tp = rel_prec[rel]['tp']
        fp = rel_prec[rel]['fp']
        raw_fn = rel_omis[rel]['raw_fn']
        cov_fn = rel_omis[rel]['kg_covered']
        gen_fn = rel_omis[rel]['genuine_fn']

        p = tp / max(1, tp + fp) * 100
        r_kg = tp / max(1, tp + gen_fn) * 100
        f1_kg = 2 * p * r_kg / max(1e-6, p + r_kg)

        print(f"{rel:<25s} | {tp:5d} | {fp:4d} | {p:7.2f} | {raw_fn:5d} | {cov_fn:5d} | {gen_fn:5d} | {r_kg:9.2f} | {f1_kg:8.2f}")
        matrix_rows.append({
            'relation': rel, 'TP': tp, 'FP': fp, 'Precision': f"{p:.2f}%",
            'RawFN': raw_fn, 'CoveredFN': cov_fn, 'GenuineFN': gen_fn,
            'Recall': f"{r_kg:.2f}%", 'F1': f"{f1_kg:.2f}%"
        })

    print("-" * 105)
    print(f"{'Overall':<25s} | {tot_tp:5d} | {tot_fp:4d} | {overall_prec:7.2f} | {tot_raw_fn:5d} | {tot_kg_cov:5d} | {tot_gen_fn:5d} | {overall_kg_r:9.2f} | {overall_kg_f1:8.2f}")
    print("=" * 105)

    print("\n" + "=" * 105)
    print("STRATA-LEVEL BENCHMARK BREAKDOWN (DISEASE, PEST, WEED)")
    print("=" * 105)
    print(f"{'Stratum':<12s} | {'Docs':>5s} | {'TP':>5s} | {'FP':>4s} | {'Prec(%)':>7s} | {'RawFN':>5s} | {'CovFN':>5s} | {'GenFN':>5s} | {'KG-Rec(%)':>9s} | {'KG-F1(%)':>8s}")
    print("-" * 105)
    strata_rows = []
    for st in ["Disease", "Pest", "Weed"]:
        docs_cnt = len(strata_prec[st]['docs']) if strata_prec[st]['docs'] else (100 if st=="Disease" else (90 if st=="Pest" else 30))
        tp = strata_prec[st]['tp']
        fp = strata_prec[st]['fp']
        raw_fn = strata_omis[st]['raw_fn']
        cov_fn = strata_omis[st]['kg_covered']
        gen_fn = strata_omis[st]['genuine_fn']

        p = tp / max(1, tp + fp) * 100
        doc_r = tp / max(1, tp + raw_fn) * 100
        doc_f1 = 2 * p * doc_r / max(1e-6, p + doc_r)
        r_kg = tp / max(1, tp + gen_fn) * 100
        f1_kg = 2 * p * r_kg / max(1e-6, p + r_kg)
        print(f"{st:<12s} | {docs_cnt:5d} | {tp:5d} | {fp:4d} | {p:7.2f} | {raw_fn:5d} | {cov_fn:5d} | {gen_fn:5d} | {r_kg:9.2f} | {f1_kg:8.2f}")
        strata_rows.append({
            'stratum': st, 'sample_count': docs_cnt, 'tp': tp, 'fp': fp,
            'raw_fn': raw_fn, 'kg_covered_fn': cov_fn, 'genuine_fn': gen_fn,
            'precision': f"{p:.2f}%", 'doc_recall': f"{doc_r:.2f}%", 'doc_f1': f"{doc_f1:.2f}%",
            'kg_recall': f"{r_kg:.2f}%", 'kg_f1': f"{f1_kg:.2f}%"
        })
    print("-" * 105)
    print(f"{'Overall':<12s} | {220:5d} | {tot_tp:5d} | {tot_fp:4d} | {overall_prec:7.2f} | {tot_raw_fn:5d} | {tot_kg_cov:5d} | {tot_gen_fn:5d} | {overall_kg_r:9.2f} | {overall_kg_f1:8.2f}")
    print("=" * 105 + "\n")

    if export_csv:
        matrix_rows.append({
            'relation': 'Overall', 'TP': tot_tp, 'FP': tot_fp, 'Precision': f"{overall_prec:.2f}%",
            'RawFN': tot_raw_fn, 'CoveredFN': tot_kg_cov, 'GenuineFN': tot_gen_fn,
            'Recall': f"{overall_kg_r:.2f}%", 'F1': f"{overall_kg_f1:.2f}%"
        })
        strata_rows.append({
            'stratum': 'OVERALL', 'sample_count': 220, 'tp': tot_tp, 'fp': tot_fp,
            'raw_fn': tot_raw_fn, 'kg_covered_fn': tot_kg_cov, 'genuine_fn': tot_gen_fn,
            'precision': f"{overall_prec:.2f}%", 'doc_recall': f"{overall_doc_r:.2f}%", 'doc_f1': f"{overall_doc_f1:.2f}%",
            'kg_recall': f"{overall_kg_r:.2f}%", 'kg_f1': f"{overall_kg_f1:.2f}%"
        })
        with open(OUTPUT_MATRIX_CSV, 'w', encoding='utf-8-sig', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['relation', 'TP', 'FP', 'Precision', 'RawFN', 'CoveredFN', 'GenuineFN', 'Recall', 'F1'])
            writer.writeheader()
            writer.writerows(matrix_rows)
        with open(OUTPUT_STRATA_CSV, 'w', encoding='utf-8-sig', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['stratum', 'sample_count', 'tp', 'fp', 'raw_fn', 'kg_covered_fn', 'genuine_fn', 'precision', 'doc_recall', 'doc_f1', 'kg_recall', 'kg_f1'])
            writer.writeheader()
            writer.writerows(strata_rows)
        print(f"Exported evaluation matrix to {OUTPUT_MATRIX_CSV}")
        print(f"Exported strata evaluation matrix to {OUTPUT_STRATA_CSV}")

def main():
    print("=" * 105)
    print("CPKG OFFICIAL BENCHMARK EVALUATION ENGINE (220-Sample Gold Standard)")
    print("Validation Protocol: Dual LLM-as-a-Judge Evaluation with Schema-Based Rule Adjudication")
    print("Benchmark Scope: 220 records spanning 70 host crops (100 disease, 90 pest, 30 weed records)")
    print("Reproduction: Dynamically Computed from Official Audit Ledgers")
    print("=" * 105 + "\n")

    if not os.path.exists(PREC_CSV) or not os.path.exists(OMIS_CSV):
        print(f"Error: Ledger files not found in {EVAL_DIR}")
        return

    # Official Primary Benchmark: Released CPKG Graph Evaluation (220-Sample Subgraph, Table 3)
    p2a, o2a, rp2a, sp2a, ro2a, so2a = run_evaluation(include_incompatible=False, eval_mode='graph_adjudicated')
    print_evaluation_report("OFFICIAL BENCHMARK: RELEASED CPKG GRAPH EVALUATION (220 SAMPLED RECORDS, TABLE 3)", p2a, o2a, rp2a, sp2a, ro2a, so2a, export_csv=True)

    # Reference Diagnostics (Pre-cleaning pipeline and unconstrained proposals)
    print("\n" + "=" * 105)
    print("REFERENCE DIAGNOSTICS & PROVENANCE COHORTS")
    print("=" * 105)
    p1, o1, rp1, sp1, ro1, so1 = run_evaluation(include_incompatible=False, eval_mode='pipeline_raw')
    tot_tp1 = sum(v['tp'] for v in rp1.values())
    tot_fp1 = sum(v['fp'] for v in rp1.values())
    tot_gen_fn1 = sum(v['genuine_fn'] for v in ro1.values())
    p1_prec = tot_tp1 / (tot_tp1 + tot_fp1) * 100
    p1_rec = tot_tp1 / (tot_tp1 + tot_gen_fn1) * 100
    p1_f1 = 2 * p1_prec * p1_rec / (p1_prec + p1_rec)
    print(f"1. Pre-Cleaning Pipeline Output (Schema-Adjudicated): Precision: {p1_prec:.2f}%, Recall: {p1_rec:.2f}%, F1: {p1_f1:.2f}% (TP={tot_tp1:,}, FP={tot_fp1:,}, FN={tot_gen_fn1:,})")

    p3, o3, rp3, sp3, ro3, so3 = run_evaluation(include_incompatible=True, eval_mode='unconstrained_baseline')
    tot_tp3 = sum(v['tp'] for v in rp3.values())
    tot_fp3 = sum(v['fp'] for v in rp3.values())
    tot_raw_fn3 = sum(v['raw_fn'] for v in ro3.values())
    tot_gen_fn3 = sum(v['genuine_fn'] for v in ro3.values())
    p3_prec = tot_tp3 / (tot_tp3 + tot_fp3) * 100
    p3_rec = tot_tp3 / (tot_tp3 + tot_gen_fn3) * 100
    p3_f1 = 2 * p3_prec * p3_rec / (p3_prec + p3_rec)
    print(f"2. Unconstrained Proposals Baseline (1,435 Candidates): Precision: {p3_prec:.2f}%, Recall: {p3_rec:.2f}%, F1: {p3_f1:.2f}% (TP={tot_tp3:,}, FP={tot_fp3:,}, FN={tot_gen_fn3:,})\n")

if __name__ == '__main__':
    main()
